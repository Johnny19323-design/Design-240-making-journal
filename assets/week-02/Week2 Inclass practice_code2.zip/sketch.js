let particles = [];
let noiseScale = 0.01;
let numParticles = 800;

function setup() {
  createCanvas(windowWidth, windowHeight);
  // Initialize particles
  for (let i = 0; i < numParticles; i++) {
    particles.push(new Particle());
  }
  background(10);
}

function draw() {
  // Use a semi-transparent background for "trails"
  background(10, 20); 

  for (let p of particles) {
    p.follow();
    p.update();
    p.checkEdges();
    p.show();
  }
}

class Particle {
  constructor() {
    this.pos = createVector(random(width), random(height));
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.maxSpeed = 2;
    this.color = color(random(100, 255), random(100, 200), 255, 150);
  }

  update() {
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    this.acc.mult(0); // Reset acceleration
  }

  // THE LEARNING PART: Using Perlin Noise to create a "Flow Field"
  follow() {
    // Generate an angle based on the particle's position in a noise field
    let angle = noise(this.pos.x * noiseScale, this.pos.y * noiseScale, frameCount * 0.005) * TWO_PI * 2;
    let force = p5.Vector.fromAngle(angle);
    force.setMag(0.5);
    this.applyForce(force);

    // Interaction: Mouse Attraction
    if (mouseIsPressed) {
      let mousePos = createVector(mouseX, mouseY);
      let steer = p5.Vector.sub(mousePos, this.pos);
      steer.setMag(1);
      this.applyForce(steer);
    }
  }

  applyForce(force) {
    this.acc.add(force);
  }

  show() {
    stroke(this.color);
    strokeWeight(2);
    point(this.pos.x, this.pos.y);
  }

  checkEdges() {
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.y > height) this.pos.y = 0;
    if (this.pos.y < 0) this.pos.y = height;
  }
}