function setup() { 
  createCanvas(400, 400);
}

function draw() {
  background('black'); // set background to white6
  fill('yellow'); // fill shapes with red7
  strokeWeight(0); // no outline for shapes8
  circle(200,250,100); // circle at (250,250) with a size of 50
  fill('green')
  rect(0,250,400,200)
  
}

