let fish = [];
let bubbles = [];
let ripples = [];
let jellyfish = [];
let nightMode = false;

function setup() {
  createCanvas(800, 600);

  for (let i = 0; i < 6; i++) {
    fish.push(new Fish(random(width), random(150, 500), random(1, 3)));
  }

  for (let i = 0; i < 3; i++) {
    jellyfish.push(new Jellyfish(random(width), random(100, 300)));
  }
}

function draw() {
  drawBackground();

  for (let f of fish) {
    f.update();
    f.display();
  }

  for (let j of jellyfish) {
    j.update();
    j.display();
  }

  for (let i = bubbles.length - 1; i >= 0; i--) {
    bubbles[i].update();
    bubbles[i].display();
    if (bubbles[i].offscreen()) {
      bubbles.splice(i, 1);
    }
  }

  for (let i = ripples.length - 1; i >= 0; i--) {
    ripples[i].update();
    ripples[i].display();
    if (ripples[i].finished()) {
      ripples.splice(i, 1);
    }
  }

  fill(255);
  textSize(16);
  text("Move mouse: bubbles", 10, 20);
  text("Click: ripple", 10, 40);
  text("Press D for day, N for night", 10, 60);
}

function drawBackground() {
  if (nightMode) {
    background(10, 30, 70);
  } else {
    background(70, 170, 220);
  }

  noStroke();
  fill(20, 100, 50, 180);
  rect(0, height - 80, width, 80);

  for (let i = 0; i < width; i += 40) {
    fill(30, 120, 70);
    rect(i, height - 80, 8, random(30, 70));
  }
}

function mouseMoved() {
  bubbles.push(new Bubble(mouseX, mouseY));
}

function mousePressed() {
  ripples.push(new Ripple(mouseX, mouseY));
}

function keyPressed() {
  if (key === 'D' || key === 'd') {
    nightMode = false;
  }
  if (key === 'N' || key === 'n') {
    nightMode = true;
  }
}

class Fish {
  constructor(x, y, speed) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.size = random(30, 50);
    this.c = color(random(100, 255), random(100, 255), random(100, 255));
  }

  update() {
    this.x += this.speed;
    this.y += sin(frameCount * 0.05 + this.x * 0.01) * 0.5;

    if (this.x > width + this.size) {
      this.x = -this.size;
      this.y = random(150, 500);
    }
  }

  display() {
    push();
    translate(this.x, this.y);
    noStroke();
    fill(this.c);
    ellipse(0, 0, this.size, this.size * 0.6);
    triangle(
      -this.size / 2, 0,
      -this.size, -this.size / 4,
      -this.size, this.size / 4
    );
    fill(255);
    ellipse(this.size / 4, -5, 6, 6);
    fill(0);
    ellipse(this.size / 4, -5, 3, 3);
    pop();
  }
}

class Bubble {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(8, 20);
    this.alpha = 180;
    this.speed = random(1, 3);
  }

  update() {
    this.y -= this.speed;
    this.x += random(-0.5, 0.5);
    this.alpha -= 2;
  }

  display() {
    noFill();
    stroke(255, this.alpha);
    ellipse(this.x, this.y, this.size);
  }

  offscreen() {
    return this.y < 0 || this.alpha <= 0;
  }
}

class Ripple {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.radius = 10;
    this.alpha = 180;
  }

  update() {
    this.radius += 3;
    this.alpha -= 3;
  }

  display() {
    noFill();
    stroke(255, this.alpha);
    ellipse(this.x, this.y, this.radius * 2);
  }

  finished() {
    return this.alpha <= 0;
  }
}

class Jellyfish {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.offset = random(TWO_PI);
    this.size = random(40, 70);
  }

  update() {
    this.y += sin(frameCount * 0.03 + this.offset) * 0.5;
    this.x += sin(frameCount * 0.02 + this.offset) * 0.3;
  }

  display() {
    push();
    translate(this.x, this.y);
    noStroke();

    if (nightMode) {
      fill(180, 150, 255, 180);
    } else {
      fill(255, 180, 220, 180);
    }

    arc(0, 0, this.size, this.size * 0.8, PI, TWO_PI);

    stroke(255, 150);
    for (let i = -2; i <= 2; i++) {
      line(i * 8, 0, i * 8 + sin(frameCount * 0.05 + i) * 10, this.size);
    }
    pop();
  }
}