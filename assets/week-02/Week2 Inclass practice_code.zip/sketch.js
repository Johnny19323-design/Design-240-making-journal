const foodData = [
  { day: "Monday", meal: "Breakfast", colors: ["red", "yellow", "white"] },
  { day: "Monday", meal: "Lunch", colors: ["green", "brown", "orange"] },
  { day: "Monday", meal: "Dinner", colors: ["purple", "white", "red"] },

  { day: "Tuesday", meal: "Breakfast", colors: ["yellow", "brown", "green"] },
  { day: "Tuesday", meal: "Lunch", colors: ["orange", "white", "purple"] },
  { day: "Tuesday", meal: "Dinner", colors: ["red", "green", "black"] },

  { day: "Wednesday", meal: "Breakfast", colors: ["white", "red", "orange"] },
  { day: "Wednesday", meal: "Lunch", colors: ["green", "yellow", "brown"] },
  { day: "Wednesday", meal: "Dinner", colors: ["purple", "white", "yellow"] },

  { day: "Thursday", meal: "Breakfast", colors: ["brown", "green", "red"] },
  { day: "Thursday", meal: "Lunch", colors: ["white", "purple", "orange"] },
  { day: "Thursday", meal: "Dinner", colors: ["yellow", "red", "green"] },

  { day: "Friday", meal: "Breakfast", colors: ["orange", "white", "brown"] },
  { day: "Friday", meal: "Lunch", colors: ["red", "yellow", "purple"] },
  { day: "Friday", meal: "Dinner", colors: ["green", "black", "white"] },

  { day: "Saturday", meal: "Breakfast", colors: ["yellow", "red", "green"] },
  { day: "Saturday", meal: "Lunch", colors: ["brown", "white", "orange"] },
  { day: "Saturday", meal: "Dinner", colors: ["purple", "green", "yellow"] },

  { day: "Sunday", meal: "Breakfast", colors: ["white", "orange", "brown"] },
  { day: "Sunday", meal: "Lunch", colors: ["red", "purple", "green"] },
  { day: "Sunday", meal: "Dinner", colors: ["yellow", "white", "black"] }
];

let daySelect;
let colorSelect;
let breakfastCheck;
let lunchCheck;
let dinnerCheck;
let resetButton;

const days = ["All Days", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const meals = ["Breakfast", "Lunch", "Dinner"];
const allColors = ["all", "red", "yellow", "white", "green", "brown", "orange", "purple", "black"];

function setup() {
  createCanvas(1000, 500);
  textFont("Arial");

  daySelect = createSelect();
  days.forEach(day => daySelect.option(day));
  daySelect.position(20, 20);

  colorSelect = createSelect();
  allColors.forEach(c => colorSelect.option(c));
  colorSelect.position(160, 20);

  breakfastCheck = createCheckbox("Breakfast", true);
  breakfastCheck.position(300, 20);

  lunchCheck = createCheckbox("Lunch", true);
  lunchCheck.position(400, 20);

  dinnerCheck = createCheckbox("Dinner", true);
  dinnerCheck.position(480, 20);

  resetButton = createButton("Reset");
  resetButton.position(580, 20);
  resetButton.mousePressed(resetFilters);
}

function draw() {
  background(250);

  fill(0);
  noStroke();
  textSize(20);
  text("Interactive Food Colour Portrait", 20, 80);

  textSize(12);
  text("Filter by day, meal, and colour. Hover over a dot to see details.", 20, 100);

  const xStart = 100;
  const yStart = 160;
  const colGap = 110;
  const rowGap = 90;

  const displayDays = days.slice(1);

  // Day labels
  fill(0);
  textSize(14);
  for (let i = 0; i < displayDays.length; i++) {
    text(displayDays[i], xStart + i * colGap - 20, yStart - 30);
  }

  // Meal labels
  for (let j = 0; j < meals.length; j++) {
    text(meals[j], 20, yStart + j * rowGap + 5);
  }

  let hoveredInfo = "";

  for (let entry of foodData) {
    const selectedDay = daySelect.value();
    const selectedColor = colorSelect.value();

    const mealVisible =
      (entry.meal === "Breakfast" && breakfastCheck.checked()) ||
      (entry.meal === "Lunch" && lunchCheck.checked()) ||
      (entry.meal === "Dinner" && dinnerCheck.checked());

    if (!mealVisible) continue;
    if (selectedDay !== "All Days" && entry.day !== selectedDay) continue;

    const dayIndex = displayDays.indexOf(entry.day);
    const mealIndex = meals.indexOf(entry.meal);

    for (let i = 0; i < entry.colors.length; i++) {
      const c = entry.colors[i];
      const x = xStart + dayIndex * colGap;
      const y = yStart + mealIndex * rowGap + i * 20;

      let alphaValue = 255;
      if (selectedColor !== "all" && c !== selectedColor) {
        alphaValue = 50;
      }

      const mapped = getColorValue(c, alphaValue);
      fill(mapped);
      stroke(80);
      ellipse(x, y, 18, 18);

      if (dist(mouseX, mouseY, x, y) < 9) {
        hoveredInfo = `${entry.day} | ${entry.meal} | ${c}`;
      }
    }
  }

  if (hoveredInfo !== "") {
    noStroke();
    fill(0);
    rect(mouseX + 10, mouseY - 25, textWidth(hoveredInfo) + 20, 24, 6);
    fill(255);
    textSize(12);
    text(hoveredInfo, mouseX + 20, mouseY - 9);
  }
}

function getColorValue(name, alphaValue) {
  if (name === "red") return color(255, 0, 0, alphaValue);
  if (name === "yellow") return color(255, 220, 0, alphaValue);
  if (name === "white") return color(245, 245, 245, alphaValue);
  if (name === "green") return color(0, 170, 80, alphaValue);
  if (name === "brown") return color(139, 90, 43, alphaValue);
  if (name === "orange") return color(255, 140, 0, alphaValue);
  if (name === "purple") return color(140, 80, 180, alphaValue);
  if (name === "black") return color(30, 30, 30, alphaValue);
  return color(180, alphaValue);
}

function resetFilters() {
  daySelect.selected("All Days");
  colorSelect.selected("all");
  breakfastCheck.checked(true);
  lunchCheck.checked(true);
  dinnerCheck.checked(true);
}